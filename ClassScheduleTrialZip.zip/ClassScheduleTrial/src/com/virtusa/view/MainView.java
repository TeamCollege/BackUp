package com.virtusa.view;

public class MainView {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentView studentView=new StudentView();
		studentView.studentMenu();
	}

}
