package com.virtusa.cma.dao;

import java.util.List;

import com.virtusa.cma.entity.Alumni;

public interface AlumniDAOIface {
	List<Alumni> showAllAlumni();
}
