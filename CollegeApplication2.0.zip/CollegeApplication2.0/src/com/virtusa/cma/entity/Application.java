package com.virtusa.cma.entity;

public class Application {
	private String firstName;
	private String lastName;
	private String contact;
	private String gender;
	private String fatherName;
	private String email;
	private double xPercentage;
	private double xiiPercentage;
}
