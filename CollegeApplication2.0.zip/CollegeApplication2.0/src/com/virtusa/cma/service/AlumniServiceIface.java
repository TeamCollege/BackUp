package com.virtusa.cma.service;

import java.util.List;

import com.virtusa.cma.entity.Alumni;

public interface AlumniServiceIface {
	List<Alumni> showAllAlumni();
}
