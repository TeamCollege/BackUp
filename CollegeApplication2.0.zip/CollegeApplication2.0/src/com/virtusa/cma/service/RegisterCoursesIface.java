package com.virtusa.cma.service;

import com.virtusa.cma.entity.RegisterCourses;

public interface RegisterCoursesIface {
	int enrollService(RegisterCourses c,String userName);
	
}
