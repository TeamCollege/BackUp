package com.virtusa.client;

import com.virtusa.view.AdminView;

public class AdminMainClass
{
	public static void main(String[] args) {
		AdminView adminView = new AdminView();
		adminView.adminView();
	}

}   
     