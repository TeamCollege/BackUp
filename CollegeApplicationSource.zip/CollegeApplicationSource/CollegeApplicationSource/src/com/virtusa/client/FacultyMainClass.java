package com.virtusa.client;

import com.virtusa.view.FacultyView;

public class FacultyMainClass {

	public static void main(String[] args) {

		FacultyView facultyView = new FacultyView();
		facultyView.facultyMenu(); 
	}

}
