package com.virtusa.entities;

public class Admin
{
	private int adminId;

	public int getAdminId() 
	{
		return adminId;
	}

	public void setAdminId(int adminId)
	{
		this.adminId = adminId;
	}
	
       
}
