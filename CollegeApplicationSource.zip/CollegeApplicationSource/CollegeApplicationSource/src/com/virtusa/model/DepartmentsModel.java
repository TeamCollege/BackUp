package com.virtusa.model;

public class DepartmentsModel {

}
      