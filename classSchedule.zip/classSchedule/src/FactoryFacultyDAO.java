


public class FactoryFacultyDAO {

	public static FacultyDAO createFacultyDAO() {
		FacultyDAO facultyDAO = new FacultyDAOImpl();
		return facultyDAO;
	}

}
