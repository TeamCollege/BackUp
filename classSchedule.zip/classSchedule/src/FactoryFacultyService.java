


public class FactoryFacultyService {

	public static FacultyService createApplicantService() {
		FacultyService facultyService=new FacultyServiceImpl();
		return facultyService;
	} 

}
