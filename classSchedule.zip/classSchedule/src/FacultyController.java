

import java.util.List;



public class FacultyController {
	
	private FacultyService facultyService;
	
	public FacultyController() {
		this.facultyService = FactoryFacultyService.createApplicantService();

	}

	public void viewClassSchedule(FacultyModel facultyModel) {
		List<ClassScheduleModel> model = facultyService.retreiveClassSchedule(facultyModel.getDepartmentName());
		FacultyView facultyView = new FacultyView();
		facultyView.displayClassSchedule(model);
	}
	
}
