

import java.sql.SQLException;
import java.util.List;


public interface FacultyDAO {
	public List<ClassSchedule> viewCLassSchedule(String departmentName) throws ClassNotFoundException, SQLException;	

}
