

import java.util.List;

public interface FacultyService {

	public List<ClassScheduleModel> retreiveClassSchedule(String departmentName);

}
