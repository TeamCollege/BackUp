package com.virtusa.controller;


public class AdminController 
{
	public void approveApplicantController()
	{
		 
	}
	
	public void addStudentController()
	{
		
	}
	public void deleteStudentController()
	{
		
	}
	public void addFacultyController()
	{
		
	}
	public void deleteFacultyController()
	{
		 
	}
	
	

}
