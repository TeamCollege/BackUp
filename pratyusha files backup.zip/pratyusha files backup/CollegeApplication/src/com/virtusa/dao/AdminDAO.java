package com.virtusa.dao;

public interface AdminDAO 
{

}
