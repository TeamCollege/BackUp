package com.virtusa.entities;

public class Faculty {

}
