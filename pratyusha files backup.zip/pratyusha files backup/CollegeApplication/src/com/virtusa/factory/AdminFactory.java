package com.virtusa.factory;

public class AdminFactory
{
	

}
