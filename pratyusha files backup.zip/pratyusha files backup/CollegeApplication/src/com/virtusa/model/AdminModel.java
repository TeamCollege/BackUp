package com.virtusa.model;

public class AdminModel 
{
	private int adminId;

}
