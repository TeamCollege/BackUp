package com.virtusa.model;

public class ExamScheduleModel {
	
	private String exam_id;
	private String exam_type;
	private String exam_name;
	private String exam_subject1;
	private String exam_subject2;
	
	
	public ExamScheduleModel() {}
	
	
	public String getExam_id() {
		return exam_id;
	}
	public void setExam_id(String exam_id) {
		this.exam_id = exam_id;
	}
	public String getExam_type() {
		return exam_type;
	}
	public void setExam_type(String exam_type) {
		this.exam_type = exam_type;
	}
	public String getExam_name() {
		return exam_name;
	}
	public void setExam_name(String exam_name) {
		this.exam_name = exam_name;
	}
	public String getExam_subject1() {
		return exam_subject1;
	}
	public void setExam_subject1(String exam_subject1) {
		this.exam_subject1 = exam_subject1;
	}
	public String getExam_subject2() {
		return exam_subject2;
	}
	public void setExam_subject2(String exam_subject2) {
		this.exam_subject2 = exam_subject2;
	}
	@Override
	public String toString() {
		return "ExamScheduleModel [exam_id=" + exam_id + ", exam_type=" + exam_type + ", exam_name=" + exam_name
				+ ", exam_subject1=" + exam_subject1 + ", exam_subject2=" + exam_subject2 + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((exam_id == null) ? 0 : exam_id.hashCode());
		result = prime * result + ((exam_name == null) ? 0 : exam_name.hashCode());
		result = prime * result + ((exam_subject1 == null) ? 0 : exam_subject1.hashCode());
		result = prime * result + ((exam_subject2 == null) ? 0 : exam_subject2.hashCode());
		result = prime * result + ((exam_type == null) ? 0 : exam_type.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExamScheduleModel other = (ExamScheduleModel) obj;
		if (exam_id == null) {
			if (other.exam_id != null)
				return false;
		} else if (!exam_id.equals(other.exam_id))
			return false;
		if (exam_name == null) {
			if (other.exam_name != null)
				return false;
		} else if (!exam_name.equals(other.exam_name))
			return false;
		if (exam_subject1 == null) {
			if (other.exam_subject1 != null)
				return false;
		} else if (!exam_subject1.equals(other.exam_subject1))
			return false;
		if (exam_subject2 == null) {
			if (other.exam_subject2 != null)
				return false;
		} else if (!exam_subject2.equals(other.exam_subject2))
			return false;
		if (exam_type == null) {
			if (other.exam_type != null)
				return false;
		} else if (!exam_type.equals(other.exam_type))
			return false;
		return true;
	}

	
	
}
