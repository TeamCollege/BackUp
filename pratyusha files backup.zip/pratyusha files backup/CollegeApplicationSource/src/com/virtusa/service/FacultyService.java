package com.virtusa.service;

import java.util.List;


public class FacultyService {

	public List<ClassSchedule> retreiveClassSchedule() {
		// TODO Auto-generated method stub
		return null;
	}

}
