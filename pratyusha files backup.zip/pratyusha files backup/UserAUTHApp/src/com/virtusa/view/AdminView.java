package com.virtusa.view;

public class AdminView {
	
	public void mainAdminView() {
		System.out.println("=======Admin View======");

	}

}
