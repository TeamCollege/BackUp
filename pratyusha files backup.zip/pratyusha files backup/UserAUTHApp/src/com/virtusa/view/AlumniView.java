package com.virtusa.view;

public class AlumniView {

	public void mainAlumniView() {
		// TODO Auto-generated method stub
		System.out.println("=======Alumni View======");
	}

}
