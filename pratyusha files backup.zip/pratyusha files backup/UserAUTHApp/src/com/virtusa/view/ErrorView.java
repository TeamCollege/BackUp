package com.virtusa.view;

public class ErrorView {
	
	public void authenticationError() {
		
		System.out.println("User Authentication Failed.");
	}

}
