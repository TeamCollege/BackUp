package com.virtusa.view;

public class FacultyView {

	public void mainFacultyView() {
		// TODO Auto-generated method stub
		
		System.out.println("=======Faculty View======");
	}

}
